package event;

public interface EventCallBack {

    public void done();
}
