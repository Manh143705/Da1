package event;

import com.raven.model.ModelItem3;
import java.awt.Component;

public interface EventItem {

    public void itemClick(Component com, ModelItem3 item);
}
