package com.raven.component;

import com.raven.model.Model_Movie1;

public class Movie2 extends javax.swing.JPanel {

    public Movie2() {
        initComponents();
        init();
    }

    private void init() {
        list.addItem(new Model_Movie1("1", "Mai (Trấn Thành)", "131:00"));
        list.addItem(new Model_Movie1("2", "Doraemon: Nobita Và Bản Giao Hưởng Địa Cầu (Imai Kazuaki)", "115:37"));
        list.addItem(new Model_Movie1("3", "Lật Mặt 7 (Lý Hải)", "138:37"));
        list.addItem(new Model_Movie1("4", "Despicable Me 4 (feat. Joe Janiak)", "95:25"));
        list.addItem(new Model_Movie1("5", "Đào, Phở Và Piano (Phi Tiến Sơn)", "100:03"));
        list.addItem(new Model_Movie1("6", "Detective Conan: Hyakuman Doru No Michishirube (Chika Nagaoka)", "111:51"));
        list.addItem(new Model_Movie1("7", "Những gã trai hư: Chơi hay bị xơi (Bilall Fallah, Adil El Arbi)", "115:59"));
        list.addItem(new Model_Movie1("8", " Kung Fu Panda 4 (Mike Mitchell)", "94:07"));
        list.addItem(new Model_Movie1("9", "Móng vuốt (Lê Thanh Sơn)", "96:00"));
        list.addItem(new Model_Movie1("10", "The Garfield Movie (Mark Dindal)", "101:51"));
        list.addItem(new Model_Movie1("11", "Gia tài của ngoại (Pat Boonnitipat)", "127:58"));
        list.addItem(new Model_Movie1("12", "Inside Out 2 (Yoichi Narita)", "127:07"));
        list.addItem(new Model_Movie1("13", "Cửu long thành trại: Vây thành (Trịnh Bảo Thụy)", "125:53"));
        list.addItem(new Model_Movie1("14", "Demon Slayer 2020 (Haruo Sotozaki)", "117:15"));
        list.addItem(new Model_Movie1("15", "Vùng đất câm lặng: Ngày 1 (Michael Sarnoski)", "111:28"));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        list = new com.raven.component.ListMovie2<>();

        setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("sansserif", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Phim Xu Hướng");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(list, javax.swing.GroupLayout.DEFAULT_SIZE, 285, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(list, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private com.raven.component.ListMovie2<String> list;
    // End of variables declaration//GEN-END:variables
}
