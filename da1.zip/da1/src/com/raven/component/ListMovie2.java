package com.raven.component;

import com.raven.model.Model_Movie1;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.SwingUtilities;

public class ListMovie2<E extends Object> extends JList<E> {

    private final DefaultListModel model;
    private int playIndex = -1;

    public ListMovie2() {
        model = new DefaultListModel();
        setModel(model);
        setOpaque(false);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                if (SwingUtilities.isLeftMouseButton(me)) {
                    playIndex = locationToIndex(me.getPoint());
                    repaint();
                }
            }
        });
    }

    @Override
    public ListCellRenderer getCellRenderer() {
        return new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> jlist, Object o, int index, boolean selected, boolean focus) {
                Model_Movie1 data;
                if (o instanceof Model_Movie1) {
                    data = (Model_Movie1) o;
                } else {
                    data = new Model_Movie1("1", "No Music", "00:00");
                }
                ItemMovie2 item = new ItemMovie2(data);
                item.setPlay(index == playIndex);
                return item;
            }
        };
    }

    public void addItem(Model_Movie1 data) {
        model.addElement(data);
    }
}
