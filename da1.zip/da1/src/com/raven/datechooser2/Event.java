package com.raven.datechooser2;

import java.awt.event.MouseEvent;

public interface Event {

    public void execute(MouseEvent evt, int num);
}
