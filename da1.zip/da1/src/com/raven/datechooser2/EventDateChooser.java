package com.raven.datechooser2;

public interface EventDateChooser {

    public void dateSelected(SelectedAction action, SelectedDate date);
}
