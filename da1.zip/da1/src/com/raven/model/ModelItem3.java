package com.raven.model;

import javax.swing.Icon;

public class ModelItem3 {
    private int itemID;
    private String itemName;
    private String maStaff;
    private String diaChi;
    private String phong;
    private String viTri;
    private String tuoi;
    private String namSinh;
    private String SDT;
    private String email;
    private String gioiTinh;
    private String maCCCD;
    private Icon image;

     public ModelItem3() {
    }
    
    public ModelItem3(int itemID, String itemName, String maStaff, String diaChi, String viTri, String tuoi, String namSinh, String SDT, String email, String gioiTinh, String maCCCD, String phong, Icon image) {
        this.itemID = itemID;
        this.itemName = itemName;
        this.maStaff = maStaff;
        this.diaChi = diaChi;
        this.phong = phong;
        this.viTri = viTri;
        this.tuoi = tuoi;
        this.namSinh = namSinh;
        this.SDT = SDT;
        this.email = email;
        this.gioiTinh = gioiTinh;
        this.maCCCD = maCCCD;
        this.image = image;
    }

    public int getItemID() {
        return itemID;
    }

    public void setItemID(int itemID) {
        this.itemID = itemID;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }
    
    public String getMaStaff() {
        return maStaff;
    }

    public void setMaStaff(String maStaff) {
        this.maStaff = maStaff;
    }
    
    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }
    
    public String getPhong() {
        return phong;
    }

    public void setPhong(String phong) {
        this.phong = phong;
    }

    public String getViTri() {
        return viTri;
    }

    public void setViTri(String viTri) {
        this.viTri = viTri;
    }

    public String getTuoi() {
        return tuoi;
    }

    public void setTuoi(String tuoi) {
        this.tuoi = tuoi;
    }

    public String getNamSinh() {
        return namSinh;
    }

    public void setNamSinh(String namSinh) {
        this.namSinh = namSinh;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getMaCCCD() {
        return maCCCD;
    }

    public void setMaCCCD(String maCCCD) {
        this.maCCCD = maCCCD;
    }
    
    public Icon getImage() {
        return image;
    }

    public void setImage(Icon image) {
        this.image = image;
    }

   
}

