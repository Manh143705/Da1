
package com.raven.model;


public class Model_Ticket2 {
    private String maVeBan;
    private String ngayBan;
    private int tongTien;
    private String gioBatDau;
    private String gioKetThuc;
    private int giaVe;
    private String maGhe;
    private String maPhong;

    public Model_Ticket2() {
    }

    public Model_Ticket2(String maVeBan, String ngayBan, int tongTien, String gioBatDau, String gioKetThuc, int giaVe, String maGhe, String maPhong) {
        this.maVeBan = maVeBan;
        this.ngayBan = ngayBan;
        this.tongTien = tongTien;
        this.gioBatDau = gioBatDau;
        this.gioKetThuc = gioKetThuc;
        this.giaVe = giaVe;
        this.maGhe = maGhe;
        this.maPhong = maPhong;
    }

    public String getMaVeBan() {
        return maVeBan;
    }

    public void setMaVeBan(String maVeBan) {
        this.maVeBan = maVeBan;
    }

    public String getNgayBan() {
        return ngayBan;
    }

    public void setNgayBan(String ngayBan) {
        this.ngayBan = ngayBan;
    }

    public int getTongTien() {
        return tongTien;
    }

    public void setTongTien(int tongTien) {
        this.tongTien = tongTien;
    }

    public String getGioBatDau() {
        return gioBatDau;
    }

    public void setGioBatDau(String gioBatDau) {
        this.gioBatDau = gioBatDau;
    }

    public String getGioKetThuc() {
        return gioKetThuc;
    }

    public void setGioKetThuc(String gioKetThuc) {
        this.gioKetThuc = gioKetThuc;
    }

    public int getGiaVe() {
        return giaVe;
    }

    public void setGiaVe(int giaVe) {
        this.giaVe = giaVe;
    }

    public String getMaGhe() {
        return maGhe;
    }

    public void setMaGhe(String maGhe) {
        this.maGhe = maGhe;
    }

    public String getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(String maPhong) {
        this.maPhong = maPhong;
    }
    
           
}
