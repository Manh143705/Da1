
package com.raven.form;

import com.raven.form.FormHome;
import com.raven.model.ModelItem3;
import event.EventItem;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import javax.swing.ImageIcon;
import org.jdesktop.animation.timing.Animator;
import org.jdesktop.animation.timing.TimingTargetAdapter;
import org.jdesktop.animation.timing.interpolation.PropertySetter;

public class Form_3 extends javax.swing.JPanel {

    private FormHome home;
    private Animator animator;
    private Point animatePoint;
    private ModelItem3 itemSelected;
    
    public Form_3() {
        initComponents();
        setBackground(new Color(0, 0, 0, 0));
        init();
        //  Animator start form animatePoint to TagetPoint
        animator = PropertySetter.createAnimator(500, mainPanel1, "imageLocation", animatePoint, mainPanel1.getTargetLocation());
        animator.addTarget(new PropertySetter(mainPanel1, "imageSize", new Dimension(180, 120), mainPanel1.getTargetSize()));
        animator.addTarget(new TimingTargetAdapter() {
            @Override
            public void end() {
                mainPanel1.setImageOld(null);
            }
        });
        animator.setResolution(0);
        animator.setAcceleration(.5f);
        animator.setDeceleration(.5f);
    }
    
    private void init() {
        home = new FormHome();
        //winButton.initEvent(this, background1);
        mainPanel1.setLayout(new BorderLayout());
        mainPanel1.add(home);
        testData();
    }

    private void testData() {
        home.setEvent(new EventItem() {
            @Override
            public void itemClick(Component com, ModelItem3 item) {
                if (itemSelected != null) {
                    mainPanel1.setImageOld(itemSelected.getImage());
                }
                if (itemSelected != item) {
                    if (!animator.isRunning()) {
                        itemSelected = item;
                        animatePoint = getLocationOf(com);
                        mainPanel1.setImage(item.getImage());
                        mainPanel1.setImageLocation(animatePoint);
                        mainPanel1.setImageSize(new Dimension(180, 120));
                        mainPanel1.repaint();
                        home.setSelected(com);
                        home.showItem(item);
                        animator.start();
                    }
                }
            }
        });
        int ID = 1;
        for (int i = 0; i <= 5; i++) {
    // Adjust the constructor parameters to match the ModelItem class definition
home.addItem(new ModelItem3(ID++, "Nguyễn Văn Mạnh", "PH56299", "Hà Nội", "Admin", "19", "2005", "0364276451", "manhnvph56299@gmail.com", "Nam", "024205006097", "Điều Hành", new ImageIcon(getClass().getResource("/com/raven/icon/test/img44.jpg"))));
home.addItem(new ModelItem3(ID++, "Trần Thị Diệu Linh", "PH56300", "Bắc Giang", "Trưởng Phòng", "19", "2005", "0364276452", "dieu.linht@gmail.com", "Nữ", "024205006098", "Kế Toán", new ImageIcon(getClass().getResource("/com/raven/icon/test/img11.jpeg"))));
home.addItem(new ModelItem3(ID++, "Phạm Như Thạch", "PH56301", "Hải Phòng", "Leader", "19", "2005", "0364276453", "thach.pham@gmail.com", "Nam", "024205006099", "Dự Án", new ImageIcon(getClass().getResource("/com/raven/icon/test/img22.jpg"))));
home.addItem(new ModelItem3(ID++, "Thân Thị Ngọc Bích", "PH56302", "Ninh Bình", "Nhân viên", "19", "2005", "0364276454", "ngoc.bich@gmail.com", "Nữ", "024205006100", "Kinh Doanh", new ImageIcon(getClass().getResource("/com/raven/icon/test/img22.jpg"))));
home.addItem(new ModelItem3(ID++, "Nguyễn Văn Thành", "PH56303", "Bắc Ninh", "Nhân viên", "19", "2005", "0364276455", "thanh.nguyen@gmail.com", "Nam", "024205006101", "Kinh Doanh", new ImageIcon(getClass().getResource("/com/raven/icon/test/img77.jpg"))));
home.addItem(new ModelItem3(ID++, "Lê Thu Hà", "PH56304", "Quảng Ninh", "Phó Chủ Tịch", "19", "2005", "0364276456", "thu.ha@gmail.com", "Nữ", "024205006102", "Vợ Admin", new ImageIcon(getClass().getResource("/com/raven/icon/test/img88.jpg"))));

}

    }

    private Point getLocationOf(Component com) {
        Point p = home.getPanelItemLocation();
        int x = p.x;
        int y = p.y;
        int itemX = com.getX();
        int itemY = com.getY();
        int left = 10;
        int top = 35;
        return new Point(x + itemX + left, y + itemY + top);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        background1 = new com.raven.swing.Background();
        mainPanel1 = new com.raven.swing.MainPanel();

        setPreferredSize(new java.awt.Dimension(1050, 557));

        background1.setPreferredSize(new java.awt.Dimension(1130, 557));

        mainPanel1.setPreferredSize(new java.awt.Dimension(1125, 523));

        javax.swing.GroupLayout mainPanel1Layout = new javax.swing.GroupLayout(mainPanel1);
        mainPanel1.setLayout(mainPanel1Layout);
        mainPanel1Layout.setHorizontalGroup(
            mainPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1125, Short.MAX_VALUE)
        );
        mainPanel1Layout.setVerticalGroup(
            mainPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 557, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout background1Layout = new javax.swing.GroupLayout(background1);
        background1.setLayout(background1Layout);
        background1Layout.setHorizontalGroup(
            background1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(background1Layout.createSequentialGroup()
                .addComponent(mainPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 5, Short.MAX_VALUE))
        );
        background1Layout.setVerticalGroup(
            background1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 557, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.raven.swing.Background background1;
    private com.raven.swing.MainPanel mainPanel1;
    // End of variables declaration//GEN-END:variables
}
