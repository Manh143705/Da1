package com.raven.form;

import com.raven.component.Item3;
//import com.raven.event.EventItem;
import com.raven.model.ModelItem3;
import com.raven.swing.ScrollBar;
import event.EventItem;
import java.awt.Component;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import javax.swing.SwingUtilities;

public class FormHome extends javax.swing.JPanel {

    public void setEvent(EventItem event) {
        this.event = event;
    }

    private EventItem event;

    public FormHome() {
        initComponents();
        scroll.setVerticalScrollBar(new ScrollBar());
    }

    public void addItem(ModelItem3 data) {
        Item3 item = new Item3();
        item.setData(data);
        item.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent me) {
                if (SwingUtilities.isLeftMouseButton(me)) {
                    event.itemClick(item, data);
                }
            }
        });
        panelItem.add(item);
        panelItem.repaint();
        panelItem.revalidate();
    }

    public void setSelected(Component item) {
        for (Component com : panelItem.getComponents()) {
            Item3 i = (Item3) com;
            if (i.isSelected()) {
                i.setSelected(false);
            }
        }
        ((Item3) item).setSelected(true);
    }

    public void showItem(ModelItem3 data) {
        lbItemName.setText(data.getItemName());
        lbIdStaff.setText(data.getMaStaff());
        txtAdress.setText(data.getDiaChi());
        lbPhong.setText(data.getPhong());
        lbViTri.setText(data.getViTri());
        lbTuoi.setText(data.getTuoi());
        lbNamSinh.setText(data.getNamSinh());
        lbSDT.setText(data.getSDT());
        lbEmail.setText(data.getEmail());
        lbGioiTinh.setText(data.getGioiTinh());
        lbCccd.setText(data.getMaCCCD());
    }

    public Point getPanelItemLocation() {
        Point p = scroll.getLocation();
        return new Point(p.x, p.y - scroll.getViewport().getViewPosition().y);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        scroll = new javax.swing.JScrollPane();
        panelItem = new com.raven.swing.PanelItem();
        jPanel1 = new javax.swing.JPanel();
        lbItemName = new javax.swing.JLabel();
        lbViTri = new javax.swing.JLabel();
        lbPhong = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        txtAdress = new javax.swing.JTextPane();
        lbIdStaff = new javax.swing.JLabel();
        lbEmail = new javax.swing.JLabel();
        lbSDT = new javax.swing.JLabel();
        lbGioiTinh = new javax.swing.JLabel();
        lbTuoi = new javax.swing.JLabel();
        lbNamSinh = new javax.swing.JLabel();
        lbCccd = new javax.swing.JLabel();
        button31 = new com.raven.swing.Button3();
        button32 = new com.raven.swing.Button3();
        textFieldAnimation1 = new swing.TextFieldAnimation();

        setOpaque(false);

        scroll.setBorder(null);
        scroll.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setViewportView(panelItem);

        jPanel1.setOpaque(false);

        lbItemName.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lbItemName.setForeground(new java.awt.Color(76, 76, 76));
        lbItemName.setText("Họ Tên NV");

        lbViTri.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lbViTri.setForeground(new java.awt.Color(76, 76, 76));
        lbViTri.setText("Vị Trí");

        lbPhong.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        lbPhong.setForeground(new java.awt.Color(76, 76, 76));
        lbPhong.setText("Phòng");

        txtAdress.setBorder(null);
        txtAdress.setFont(new java.awt.Font("sansserif", 1, 14)); // NOI18N
        txtAdress.setForeground(new java.awt.Color(178, 178, 178));
        txtAdress.setFocusable(false);

        lbIdStaff.setFont(new java.awt.Font("Segoe UI", 1, 19)); // NOI18N
        lbIdStaff.setText("ID Staff");

        lbEmail.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lbEmail.setText("Email");

        lbSDT.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lbSDT.setText("SĐT");

        lbGioiTinh.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lbGioiTinh.setText("Giới Tính");

        lbTuoi.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lbTuoi.setText("Tuổi");

        lbNamSinh.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lbNamSinh.setText("Năm Sinh");

        lbCccd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lbCccd.setText("CCCD");

        button31.setBackground(new java.awt.Color(222, 212, 92));
        button31.setText("Delete");

        button32.setBackground(new java.awt.Color(222, 207, 88));
        button32.setText("Update");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(button31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(button32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbPhong)
                            .addComponent(lbTuoi))
                        .addGap(85, 85, 85))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbViTri)
                            .addComponent(lbIdStaff)
                            .addComponent(lbItemName, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbNamSinh)
                            .addComponent(lbGioiTinh)
                            .addComponent(lbSDT)
                            .addComponent(lbEmail)
                            .addComponent(lbCccd)))
                    .addComponent(txtAdress, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(176, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbItemName)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbIdStaff)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbViTri)
                    .addComponent(lbPhong, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbNamSinh)
                    .addComponent(lbTuoi))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbGioiTinh)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbSDT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbEmail)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbCccd)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtAdress, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(button31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(button32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        textFieldAnimation1.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(scroll, javax.swing.GroupLayout.PREFERRED_SIZE, 1065, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(textFieldAnimation1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(textFieldAnimation1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scroll))
        );
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.raven.swing.Button3 button31;
    private com.raven.swing.Button3 button32;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lbCccd;
    private javax.swing.JLabel lbEmail;
    private javax.swing.JLabel lbGioiTinh;
    private javax.swing.JLabel lbIdStaff;
    private javax.swing.JLabel lbItemName;
    private javax.swing.JLabel lbNamSinh;
    private javax.swing.JLabel lbPhong;
    private javax.swing.JLabel lbSDT;
    private javax.swing.JLabel lbTuoi;
    private javax.swing.JLabel lbViTri;
    private com.raven.swing.PanelItem panelItem;
    private javax.swing.JScrollPane scroll;
    private swing.TextFieldAnimation textFieldAnimation1;
    private javax.swing.JTextPane txtAdress;
    // End of variables declaration//GEN-END:variables
}
