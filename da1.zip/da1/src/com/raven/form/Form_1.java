package com.raven.form;

import com.raven.chart.ModelChartLine1;
import com.raven.chart.ModelChartPie1;
import com.raven.model.ModelStaff1;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;

public class Form_1 extends javax.swing.JPanel {

    public Form_1() {
        initComponents();
        initData();
    }

    private void initData() {
        //  Test Data table
        DefaultTableModel model = (DefaultTableModel) table1.getModel();
        Random r = new Random();
        for (int i = 0; i < 20; i++) {
            String status;
            int ran = r.nextInt(3);
            if (ran == 0) {
                status = "Chờ Duyệt";
            } else if (ran == 1) {
                status = "Đã Duyệt";
            } else {
                status = "Hủy";
            }
            model.addRow(new ModelStaff1(new ImageIcon(getClass().getResource("/com/raven/icon/staff.jpg")), "Nguyễn Văn Mạnh", "Nam", "manhnvph56299@gmail.com", status).toDataTable());
            model.addRow(new ModelStaff1(new ImageIcon(getClass().getResource("/com/raven/icon/staff.jpg")), "Trần Thị Lan", "Nữ", "lanttph54399@gmail.com", status).toDataTable());
            model.addRow(new ModelStaff1(new ImageIcon(getClass().getResource("/com/raven/icon/staff.jpg")), "Lê Xuân Nhất", "Nam", "nhatlxph54347@gmail.com", status).toDataTable());
            model.addRow(new ModelStaff1(new ImageIcon(getClass().getResource("/com/raven/icon/staff.jpg")), "Thân Thị Ngọc Bích", "Nữ", "bichttnph51367@gmail.com", status).toDataTable());
        }
        table1.fixTable(jScrollPane1);
        List<ModelChartPie1> list1 = new ArrayList<>();
        list1.add(new ModelChartPie1("Monday", 1000, new Color(4, 174, 243)));
        list1.add(new ModelChartPie1("Tuesday", 1500, new Color(215, 39, 250)));
        list1.add(new ModelChartPie1("Wednesday", 800, new Color(44, 88, 236)));
        list1.add(new ModelChartPie1("Thursday", 1009, new Color(21, 202, 87)));
        list1.add(new ModelChartPie1("Friday", 1258, new Color(127, 63, 255)));
        list1.add(new ModelChartPie1("Saturday", 803, new Color(238, 167, 35)));
        list1.add(new ModelChartPie1("Sunday", 2070, new Color(245, 79, 99)));
        chartPie.setModel(list1);
        //  Test data chart line
        List<ModelChartLine1> list = new ArrayList<>();
        list.add(new ModelChartLine1("Monday", 10000000));
        list.add(new ModelChartLine1("Tuesday", 15000000));
        list.add(new ModelChartLine1("Wednesday", 8000000));
        list.add(new ModelChartLine1("Thursday", 20000000));
        list.add(new ModelChartLine1("Friday", 12500000));
        list.add(new ModelChartLine1("Saturday", 27000000));
        list.add(new ModelChartLine1("Sunday", 14000000));
        chartLine1.setModel(list);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        chartPie = new com.raven.chart.ChartPie1();
        chartLine1 = new com.raven.chart.ChartLine1();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table1 = new com.raven.swing.Table1();

        setBackground(new java.awt.Color(250, 250, 250));

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(66, 66, 66));
        jLabel1.setText("Danh Sách Đặt Vé");

        table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Hình", "Họ Tên", "Giới Tính", "Email", "Trạng Thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(table1);
        if (table1.getColumnModel().getColumnCount() > 0) {
            table1.getColumnModel().getColumn(0).setPreferredWidth(50);
            table1.getColumnModel().getColumn(4).setPreferredWidth(50);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(chartLine1, javax.swing.GroupLayout.DEFAULT_SIZE, 553, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(chartPie, javax.swing.GroupLayout.DEFAULT_SIZE, 529, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(chartLine1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(chartPie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.raven.chart.ChartLine1 chartLine1;
    private com.raven.chart.ChartPie1 chartPie;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private com.raven.swing.Table1 table1;
    // End of variables declaration//GEN-END:variables
}
